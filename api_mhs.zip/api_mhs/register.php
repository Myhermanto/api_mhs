<?php
$host = 'localhost';
$dbname = 'api_mobile';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nim = $_POST['nim'];
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $kampus = $_POST['kampus'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (nim, nama, kelas, kampus, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nim, $nama, $kelas, $kampus, $password]);

        echo json_encode(['status' => 'success', 'message' => 'Registration successful']);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
