import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nimController = TextEditingController();
  final TextEditingController _namaController = TextEditingController();
  final TextEditingController _kelasController = TextEditingController();
  final TextEditingController _kampusController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<void> register() async {
    final response = await http.post(
      Uri.parse('http://localhost/api_mhs/register.php'),
      body: {
        'nim': _nimController.text,
        'nama': _namaController.text,
        'kelas': _kelasController.text,
        'kampus': _kampusController.text,
        'password': _passwordController.text,
      },
    );

    final responseData = json.decode(response.body);

    // Menampilkan dialog berdasarkan status respons
    if (responseData['status'] == 'success') {
      // Jika berhasil daftar
      _showDialog(
          'Pendaftaran Berhasil', 'Akun anda berhasil didaftarkan!', true);
    } else {
      // Jika gagal daftar
      _showDialog(
          'Pendaftaran Gagal', 'Terjadi kesalahan saat pendaftaran.', false);
    }
  }

  // Fungsi untuk menampilkan dialog alert
  void _showDialog(String title, String message, bool isSuccess) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop(); // Menutup dialog
              if (isSuccess) {
                Navigator.pop(
                    context); // Kembali ke halaman login jika registrasi berhasil
              }
            },
            child: Text('Tutup'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pendaftaran Mahasiswa')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nimController,
                decoration: InputDecoration(labelText: 'NIM'),
                validator: (value) =>
                    value!.isEmpty ? 'NIM tidak boleh kosong' : null,
              ),
              TextFormField(
                controller: _namaController,
                decoration: InputDecoration(labelText: 'Nama'),
                validator: (value) =>
                    value!.isEmpty ? 'Nama tidak boleh kosong' : null,
              ),
              TextFormField(
                controller: _kelasController,
                decoration: InputDecoration(labelText: 'Kelas'),
              ),
              TextFormField(
                controller: _kampusController,
                decoration: InputDecoration(labelText: 'Kampus'),
              ),
              TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (value) =>
                    value!.isEmpty ? 'Password tidak boleh kosong' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    register();
                  }
                },
                child: Text('Daftar'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
